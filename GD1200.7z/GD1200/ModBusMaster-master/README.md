ModBusMaster
============

ModBusMaster port for Spark

Adapted for Spark Core by Paul Kourany, March 14, 2014
