ModBusMaster
============

ModBusMaster port for Spark
